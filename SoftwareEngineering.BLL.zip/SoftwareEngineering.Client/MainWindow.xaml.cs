﻿using SoftwareEngineering.BLL.Exceptions;
using SoftwareEngineering.BLL.Interfaces;
using SoftwareEngineering.BLL.Models;
using SoftwareEngineering.DAL.Enums;
using System.Windows;
using System.Windows.Controls;

namespace SoftwareEngineering.Client
{
    public partial class MainWindow : Window
    {
        private readonly ITaskService taskService;
        private readonly IProjectService projectService;
        private IReadOnlyList<TaskModel> allTasks = new List<TaskModel>();

        public MainWindow(ITaskService taskService, IProjectService projectService)
        {
            InitializeComponent();
            this.taskService = taskService ?? throw new ArgumentNullException(nameof(taskService));
            this.projectService = projectService ?? throw new ArgumentNullException(nameof(projectService));

            DeadlineDatePicker.SelectedDate = DateTime.Now.AddDays(1);
            Loaded += async (_, _) => await LoadTasksAsync();
        }

        // ---------- Навігація ----------
        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton { Tag: string page })
            {
                ShowPage(page);
            }
        }

        private void ShowPage(string page)
        {
            foreach (FrameworkElement element in PagesHost.Children)
            {
                element.Visibility = element.Name == $"Page_{page}" ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private void GoToCreate_Click(object sender, RoutedEventArgs e)
        {
            ShowPage("Create");
        }

        // ---------- Завантаження даних ----------
        private async Task LoadTasksAsync()
        {
            try
            {
                allTasks = await taskService.GetAllAsync();
                ApplyFilter();
                UpdateStats();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не вдалося завантажити завдання: {ex.Message}", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilter()
        {
            var query = SearchBox.Text?.Trim() ?? string.Empty;
            TasksDataGrid.ItemsSource = string.IsNullOrEmpty(query)
                ? allTasks
                : allTasks.Where(t => t.Title.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (allTasks != null)
            {
                ApplyFilter();
            }
        }

        private void UpdateStats()
        {
            var now = DateTime.UtcNow;
            var total = allTasks.Count;
            var done = allTasks.Count(t => t.Status == TaskItemStatus.Done);
            var inProgress = allTasks.Count(t => t.Status == TaskItemStatus.InProgress);
            var overdue = allTasks.Count(t => t.Status != TaskItemStatus.Done && t.Deadline.HasValue && t.Deadline.Value.ToUniversalTime() < now);
            var active = total - done;

            StatTotal.Text = total.ToString();
            StatInProgress.Text = inProgress.ToString();
            StatDone.Text = done.ToString();
            StatOverdue.Text = overdue.ToString();

            UpcomingList.ItemsSource = allTasks
                .Where(t => t.Status != TaskItemStatus.Done)
                .OrderBy(t => t.Deadline)
                .Take(5)
                .ToList();

            AnTotal.Text = $"Загальна кількість завдань: {total}";
            AnDone.Text = $"Виконано: {done}";
            AnActive.Text = $"Невиконано: {active}";
            AnOverdue.Text = $"Протерміновано: {overdue}";
            AnProgress.Value = total == 0 ? 0 : done * 100.0 / total;
        }

        // ---------- Створення завдання (UC 1) ----------
        private async void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var priority = TaskPriority.Medium;
                if (PriorityComboBox.SelectedItem is ComboBoxItem { Tag: TaskPriority parsed })
                {
                    priority = parsed;
                }

                var project = await projectService.GetOrCreateByNameAsync(ProjectTextBox.Text ?? string.Empty);

                await taskService.CreateAsync(new TaskModel
                {
                    ProjectId = project.Id,
                    Title = TitleTextBox.Text?.Trim() ?? string.Empty,
                    Description = DescriptionTextBox.Text?.Trim() ?? string.Empty,
                    Deadline = DeadlineDatePicker.SelectedDate ?? DateTime.Now,
                    Priority = priority,
                    Status = TaskItemStatus.Todo,
                });

                MessageBox.Show("Завдання успішно створено!", "Успіх", MessageBoxButton.OK, MessageBoxImage.Information);

                TitleTextBox.Clear();
                DescriptionTextBox.Clear();
                await LoadTasksAsync();
                ShowPage("Tasks");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Помилка валідації", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Сталася помилка: {ex.Message}", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelCreate_Click(object sender, RoutedEventArgs e)
        {
            ShowPage("Tasks");
        }

        // ---------- Дії зі списку (діалоги колег) ----------
        private void ViewDetailsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (TasksDataGrid.SelectedItem is TaskModel selected)
            {
                new TaskDetailsWindow(taskService, selected.Id) { Owner = this }.ShowDialog();
            }
            else
            {
                MessageBox.Show("Виберіть завдання для перегляду.", "Увага", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private async void EditTaskMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (TasksDataGrid.SelectedItem is TaskModel selected)
            {
                if (new EditTaskWindow(taskService, selected) { Owner = this }.ShowDialog() == true)
                {
                    await LoadTasksAsync();
                }
            }
            else
            {
                MessageBox.Show("Виберіть завдання для редагування.", "Увага", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private async void DeleteTaskMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (new DeleteTaskWindow(taskService) { Owner = this }.ShowDialog() == true)
            {
                await LoadTasksAsync();
            }
        }

        // 7
        private async void UpdateProgressMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (new UpdateProgressWindow(taskService) { Owner = this }.ShowDialog() == true)
            {
                await LoadTasksAsync();
            }
        }
    }
}